%% EO comb and c.w laser spectrum plot
clear all
clc

load('211027_EO_Comb_Res_0p01nm_spectrum.mat')

figure
hold on
plot(wl,power)

load('211027_Laser_Res_0p01nm_spectrum.mat')
hold on
plot(wl,power)
xlabel('Wavelength (nm)')
ylabel('Power (dBm)')


%% EO comb pulse width

clear all
clc
load('EO comb pulse with phase dispersion 2 two cycles 0p91psPW.mat')

figure
hold on
% plot(wl,power)

pulse = power_averaged_ChB;
pulse = pulse-min(pulse);
t_vect = time_averaged_ChB;

plot(t_vect,pulse)
pulse = pulse(40 < t_vect & t_vect < 80);
t_vect = t_vect(40 < t_vect & t_vect < 80);


halfMax = (min(pulse) + max(pulse)) / 2;
index1 = find(pulse >= halfMax, 1, 'first');
index2 = find(pulse >= halfMax, 1, 'last');
fwhmx = t_vect(index2) - t_vect(index1);

txt = ['\sigma_t = ' num2str(fwhmx) ' ps'];
text_width = text(0,0.4,txt,'HorizontalAlignment','center');
text_width.FontSize = 14;

xlabel('Time (nm)')
ylabel('Power (dBm)')
% figure(8)
% hold on
% print(gcf, 'Fig1.pdf', '-dpdf', '-fillpage')

%%  Spectrum analyzer phase noise measurement

clc
clear all

raw_data = csvread('COMB 1KM FIBER PHASE NOISE 35GA.csv',23,0)

figure
% hold on
semilogx(raw_data(:,1),raw_data(:,2))
xlabel('Offset freqeuncy (Hz)')
ylabel('Phase noise (dBc/Hz)')

%% spectrum analyzer peak power
clc
clear all

raw_data = csvread('COMB 1KM FIBER RF POWER.csv',16,0)

freq = linspace(25049442790,25050442790,length(raw_data))';

figure
hold on
plot(freq*1e-9,raw_data(:,1))
xlabel('RF frequency (GHz)')
ylabel('Power (dBm)')



%%  Specturm of Signal/idler and pump plot

clear all
clc

load('PSA without NLF spectrum.mat')

power_no_NLF = power;

figure
hold on
plot(wl,power_no_NLF)

load('PSA with NLF spectrum_4p5pidiv5_phaseatcenter.mat')

power_NLF = power;

power_loss = max(power_no_NLF)-max(power_NLF);

% figure
hold on
plot(wl,power_NLF+power_loss)
xlabel('wavelength (nm)')
ylabel('Power (dBm)')


%% Gain plot

load('PSA_gain.mat')
figure
plot(phi,Gain)
xlabel('\phi/\pi')
ylabel('Gain')













